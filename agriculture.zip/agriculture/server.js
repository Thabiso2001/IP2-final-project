const express = require('express');
const path = require('path');
const mysql = require('mysql2');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 3000;

// Increase payload limit for image uploads
app.use(express.static('public'));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ============ INPUT VALIDATION FUNCTIONS ============

// Email validation
const isValidEmail = (email) => {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
};

// Phone validation (South African format)
const isValidPhone = (phone) => {
    const phoneRegex = /^(\+27|0)[6-8][0-9]{8}$/;
    return phoneRegex.test(phone);
};

// Password strength validation
const isStrongPassword = (password) => {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    return passwordRegex.test(password);
};

// Sanitize input
const sanitizeInput = (input) => {
    if (typeof input !== 'string') return input;
    return input.trim().replace(/[<>]/g, '');
};

// ============ MySQL Database Connection ============
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'farmconnect',
    port: 3306,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
    enableKeepAlive: true,
    keepAliveInitialDelay: 0
});

const db = pool.promise();

// Test database connection
async function testConnection() {
    try {
        const connection = await db.getConnection();
        console.log('✅ MySQL connected successfully!');
        connection.release();
        return true;
    } catch (error) {
        console.error('❌ MySQL connection failed:', error.message);
        return false;
    }
}

testConnection();

// ============ ROUTES FOR SERVING HTML PAGES ============

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/farmer', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'farmer-login.html'));
});

app.get('/farmer-register.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'farmer-register.html'));
});

app.get('/farmer-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'farmer-dashboard.html'));
});

app.get('/farmer-profile.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'farmer-profile.html'));
});

app.get('/farmer-orders.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'farmer-orders.html'));
});

app.get('/products.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'products.html'));
});

app.get('/buyer', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'buyer-login.html'));
});

app.get('/buyer-register.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'buyer-register.html'));
});

app.get('/buyer-dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'buyer-dashboard.html'));
});

app.get('/buyer-cart.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'buyer-cart.html'));
});

app.get('/buyer-checkout.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'buyer-checkout.html'));
});

app.get('/buyer-orders.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'buyer-orders.html'));
});

app.get('/farmbot-chat.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'farmbot-chat.html'));
});

app.get('/disease-detector.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'disease-detector.html'));
});

// ============ API ROUTES - STATS ============

app.get('/api/stats', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        
        const [farmers] = await connection.execute('SELECT COUNT(*) as count FROM farmers');
        const [products] = await connection.execute('SELECT COUNT(*) as count FROM products WHERE quantity > 0 AND status = "available"');
        const [orders] = await connection.execute('SELECT COUNT(*) as count FROM orders');
        
        connection.release();
        
        res.json({ 
            success: true, 
            totalFarmers: farmers[0].count,
            totalProducts: products[0].count,
            totalOrders: orders[0].count
        });
        
    } catch (error) {
        console.error('Error fetching stats:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

// GET farmer dashboard stats
app.get('/api/farmer/stats/:farmerId', async (req, res) => {
    let connection;
    try {
        const farmerId = parseInt(req.params.farmerId);
        
        if (isNaN(farmerId)) {
            return res.status(400).json({ error: 'Invalid farmer ID' });
        }
        
        connection = await db.getConnection();
        
        const [products] = await connection.execute(
            'SELECT COUNT(*) as count FROM products WHERE farmer_id = ?',
            [farmerId]
        );
        
        const [orders] = await connection.execute(
            'SELECT COUNT(*) as count FROM orders WHERE farmer_id = ?',
            [farmerId]
        );
        
        const [revenue] = await connection.execute(
            'SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE farmer_id = ? AND status != "cancelled"',
            [farmerId]
        );
        
        const [lowStock] = await connection.execute(
            'SELECT COUNT(*) as count FROM products WHERE farmer_id = ? AND quantity < 10 AND quantity > 0',
            [farmerId]
        );
        
        connection.release();
        
        res.json({ 
            success: true,
            totalProducts: products[0].count,
            totalOrders: orders[0].count,
            totalRevenue: revenue[0].total || 0,
            lowStock: lowStock[0].count
        });
        
    } catch (error) {
        console.error('Error fetching farmer stats:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

// ============ API ROUTES - AUTHENTICATION ============

// FARMER REGISTRATION
app.post('/api/farmer/register', async (req, res) => {
    console.log('✅ POST /api/farmer/register');
    
    let connection;
    try {
        let { firstName, lastName, email, password, phone, farmName, state, city, address, farmSize, products, bio } = req.body;
        
        firstName = sanitizeInput(firstName);
        lastName = sanitizeInput(lastName);
        email = email.toLowerCase().trim();
        phone = sanitizeInput(phone);
        farmName = sanitizeInput(farmName);
        state = sanitizeInput(state);
        city = sanitizeInput(city);
        address = sanitizeInput(address);
        bio = bio ? sanitizeInput(bio) : null;
        products = products ? sanitizeInput(products) : null;
        
        if (!firstName || !lastName || !email || !password || !phone || !farmName || !state || !city || !address) {
            return res.status(400).json({ error: 'Please fill in all required fields' });
        }
        
        if (!isValidEmail(email)) {
            return res.status(400).json({ error: 'Please enter a valid email address' });
        }
        
        if (!isValidPhone(phone)) {
            return res.status(400).json({ error: 'Please enter a valid South African phone number (e.g., 0712345678 or +27712345678)' });
        }
        
        if (!isStrongPassword(password)) {
            return res.status(400).json({ error: 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number' });
        }
        
        connection = await db.getConnection();
        
        const [existingUsers] = await connection.execute(
            'SELECT id FROM farmers WHERE email = ?',
            [email]
        );
        
        if (existingUsers.length > 0) {
            connection.release();
            return res.status(400).json({ error: 'This email is already registered' });
        }
        
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        
        const [result] = await connection.execute(
            `INSERT INTO farmers (first_name, last_name, email, password, phone, farm_name, state, city, address, farm_size, products_grown, bio) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [firstName, lastName, email, hashedPassword, phone, farmName, state, city, address, farmSize || null, products || null, bio || null]
        );
        
        console.log('✅ Farmer registered with ID:', result.insertId);
        connection.release();
        
        res.status(201).json({ 
            success: true, 
            message: 'Registration successful!',
            farmerId: result.insertId
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

// FARMER LOGIN
app.post('/api/farmer/login', async (req, res) => {
    console.log('✅ POST /api/farmer/login');
    
    let connection;
    try {
        let { email, password } = req.body;
        
        email = email.toLowerCase().trim();
        
        if (!email || !password) {
            return res.status(400).json({ error: 'Please enter email and password' });
        }
        
        connection = await db.getConnection();
        
        const [farmers] = await connection.execute(
            'SELECT id, first_name, last_name, email, farm_name, city, state, phone, password FROM farmers WHERE email = ?',
            [email]
        );
        
        if (farmers.length === 0) {
            connection.release();
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        const farmer = farmers[0];
        const isValidPassword = await bcrypt.compare(password, farmer.password);
        
        if (!isValidPassword) {
            connection.release();
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        delete farmer.password;
        
        connection.release();
        
        res.json({ 
            success: true, 
            message: 'Login successful!',
            farmer: farmer
        });
        
    } catch (error) {
        console.error('Login error:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

// BUYER REGISTRATION
app.post('/api/buyer/register', async (req, res) => {
    console.log('✅ POST /api/buyer/register');
    
    let connection;
    try {
        let { firstName, lastName, email, password, phone, city, state, address, pincode, businessType, preferredProducts, notes } = req.body;
        
        firstName = sanitizeInput(firstName);
        lastName = sanitizeInput(lastName);
        email = email.toLowerCase().trim();
        phone = sanitizeInput(phone);
        city = sanitizeInput(city);
        state = sanitizeInput(state);
        address = sanitizeInput(address);
        pincode = pincode ? sanitizeInput(pincode) : null;
        businessType = businessType ? sanitizeInput(businessType) : null;
        preferredProducts = preferredProducts ? sanitizeInput(preferredProducts) : null;
        notes = notes ? sanitizeInput(notes) : null;
        
        if (!firstName || !lastName || !email || !password || !phone || !city || !state || !address) {
            return res.status(400).json({ error: 'Please fill in all required fields' });
        }
        
        if (!isValidEmail(email)) {
            return res.status(400).json({ error: 'Please enter a valid email address' });
        }
        
        if (!isValidPhone(phone)) {
            return res.status(400).json({ error: 'Please enter a valid South African phone number' });
        }
        
        if (!isStrongPassword(password)) {
            return res.status(400).json({ error: 'Password must be at least 8 characters with 1 uppercase, 1 lowercase, and 1 number' });
        }
        
        connection = await db.getConnection();
        
        const [existingUsers] = await connection.execute(
            'SELECT id FROM buyers WHERE email = ?',
            [email]
        );
        
        if (existingUsers.length > 0) {
            connection.release();
            return res.status(400).json({ error: 'This email is already registered' });
        }
        
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);
        
        const [result] = await connection.execute(
            `INSERT INTO buyers (first_name, last_name, email, password, phone, city, state, address, pincode, business_type, preferred_products, notes) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [firstName, lastName, email, hashedPassword, phone, city, state, address, pincode, businessType, preferredProducts, notes]
        );
        
        console.log('✅ Buyer registered with ID:', result.insertId);
        connection.release();
        
        res.status(201).json({ 
            success: true, 
            message: 'Registration successful!',
            buyerId: result.insertId
        });
        
    } catch (error) {
        console.error('Registration error:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

// BUYER LOGIN
app.post('/api/buyer/login', async (req, res) => {
    console.log('✅ POST /api/buyer/login');
    
    let connection;
    try {
        let { email, password } = req.body;
        
        email = email.toLowerCase().trim();
        
        if (!email || !password) {
            return res.status(400).json({ error: 'Please enter email and password' });
        }
        
        connection = await db.getConnection();
        
        const [buyers] = await connection.execute(
            'SELECT id, first_name, last_name, email, city, state, phone, password FROM buyers WHERE email = ?',
            [email]
        );
        
        if (buyers.length === 0) {
            connection.release();
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        const buyer = buyers[0];
        const isValidPassword = await bcrypt.compare(password, buyer.password);
        
        if (!isValidPassword) {
            connection.release();
            return res.status(401).json({ error: 'Invalid email or password' });
        }
        
        delete buyer.password;
        
        connection.release();
        
        res.json({ 
            success: true, 
            message: 'Login successful!',
            buyer: buyer
        });
        
    } catch (error) {
        console.error('Login error:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

// ============ API ROUTES - PRODUCTS ============

app.get('/api/products/all', async (req, res) => {
    let connection;
    try {
        connection = await db.getConnection();
        
        const [products] = await connection.execute(
            `SELECT p.*, f.farm_name, f.city, f.state 
             FROM products p
             JOIN farmers f ON p.farmer_id = f.id
             WHERE p.quantity > 0 AND p.status = 'available'
             ORDER BY p.created_at DESC`
        );
        
        connection.release();
        res.json({ success: true, products: products });
        
    } catch (error) {
        console.error('Error fetching products:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

app.get('/api/products/farmer/:farmerId', async (req, res) => {
    let connection;
    try {
        const farmerId = parseInt(req.params.farmerId);
        
        if (isNaN(farmerId)) {
            return res.status(400).json({ error: 'Invalid farmer ID' });
        }
        
        connection = await db.getConnection();
        
        const [products] = await connection.execute(
            'SELECT * FROM products WHERE farmer_id = ? ORDER BY created_at DESC',
            [farmerId]
        );
        
        connection.release();
        res.json({ success: true, products: products });
        
    } catch (error) {
        console.error('Error fetching products:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

app.post('/api/products', async (req, res) => {
    let connection;
    console.log('✅ POST /api/products - Adding new product');
    
    try {
        let { farmerId, name, category, price, quantity, unit, description, image_url } = req.body;
        
        farmerId = parseInt(farmerId);
        if (isNaN(farmerId)) {
            return res.status(400).json({ error: 'Invalid farmer ID' });
        }
        
        name = sanitizeInput(name);
        if (!name || name.trim() === '') {
            return res.status(400).json({ error: 'Product name is required' });
        }
        
        price = parseFloat(price);
        if (isNaN(price) || price <= 0 || price > 1000000) {
            return res.status(400).json({ error: 'Valid price is required (1 - 1,000,000)' });
        }
        
        quantity = parseInt(quantity);
        if (isNaN(quantity) || quantity < 0 || quantity > 100000) {
            return res.status(400).json({ error: 'Valid quantity is required (0 - 100,000)' });
        }
        
        category = category ? sanitizeInput(category) : null;
        description = description ? sanitizeInput(description) : null;
        
        if (image_url && image_url.length > 5 * 1024 * 1024) {
            return res.status(400).json({ error: 'Image too large. Maximum 5MB' });
        }
        
        connection = await db.getConnection();
        
        const [result] = await connection.execute(
            `INSERT INTO products (farmer_id, name, category, price, quantity, unit, description, image_url, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available')`,
            [farmerId, name.trim(), category, price, quantity, unit || 'kg', description, image_url || null]
        );
        
        console.log('✅ Product added successfully with ID:', result.insertId);
        connection.release();
        
        res.status(201).json({ 
            success: true, 
            message: 'Product added successfully!',
            productId: result.insertId
        });
        
    } catch (error) {
        console.error('Error adding product:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

app.delete('/api/products/:productId', async (req, res) => {
    let connection;
    try {
        const productId = parseInt(req.params.productId);
        
        if (isNaN(productId)) {
            return res.status(400).json({ error: 'Invalid product ID' });
        }
        
        connection = await db.getConnection();
        
        const [result] = await connection.execute(
            'DELETE FROM products WHERE id = ?',
            [productId]
        );
        
        connection.release();
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Product not found' });
        }
        
        res.json({ success: true, message: 'Product deleted successfully' });
        
    } catch (error) {
        console.error('Error deleting product:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

app.put('/api/products/:productId/quantity', async (req, res) => {
    let connection;
    try {
        const productId = parseInt(req.params.productId);
        let { quantity } = req.body;
        
        if (isNaN(productId)) {
            return res.status(400).json({ error: 'Invalid product ID' });
        }
        
        quantity = parseInt(quantity);
        if (isNaN(quantity) || quantity < 0) {
            return res.status(400).json({ error: 'Valid quantity is required' });
        }
        
        connection = await db.getConnection();
        
        const [result] = await connection.execute(
            'UPDATE products SET quantity = ? WHERE id = ?',
            [quantity, productId]
        );
        
        connection.release();
        
        res.json({ success: true, message: 'Quantity updated successfully' });
        
    } catch (error) {
        console.error('Error updating quantity:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

// ============ API ROUTES - FARMER PROFILE ============

app.get('/api/farmer/profile/:farmerId', async (req, res) => {
    let connection;
    try {
        const farmerId = parseInt(req.params.farmerId);
        
        if (isNaN(farmerId)) {
            return res.status(400).json({ error: 'Invalid farmer ID' });
        }
        
        connection = await db.getConnection();
        
        const [farmers] = await connection.execute(
            'SELECT id, first_name, last_name, email, phone, farm_name, state, city, address, farm_size, products_grown, bio FROM farmers WHERE id = ?',
            [farmerId]
        );
        
        connection.release();
        
        if (farmers.length === 0) {
            return res.status(404).json({ error: 'Farmer not found' });
        }
        
        res.json({ success: true, farmer: farmers[0] });
        
    } catch (error) {
        console.error('Error fetching profile:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

app.put('/api/farmer/profile/update', async (req, res) => {
    let connection;
    console.log('✅ PUT /api/farmer/profile/update');
    
    try {
        let { farmerId, firstName, lastName, email, phone, farmName, state, city, address, farmSize, products, bio } = req.body;
        
        farmerId = parseInt(farmerId);
        if (isNaN(farmerId)) {
            return res.status(400).json({ error: 'Invalid farmer ID' });
        }
        
        firstName = sanitizeInput(firstName);
        lastName = sanitizeInput(lastName);
        email = email ? email.toLowerCase().trim() : null;
        phone = sanitizeInput(phone);
        farmName = sanitizeInput(farmName);
        state = sanitizeInput(state);
        city = sanitizeInput(city);
        address = sanitizeInput(address);
        products = products ? sanitizeInput(products) : null;
        bio = bio ? sanitizeInput(bio) : null;
        
        if (email && !isValidEmail(email)) {
            return res.status(400).json({ error: 'Please enter a valid email address' });
        }
        
        connection = await db.getConnection();
        
        const [result] = await connection.execute(
            `UPDATE farmers SET 
                first_name = ?, 
                last_name = ?, 
                email = ?, 
                phone = ?, 
                farm_name = ?, 
                state = ?, 
                city = ?, 
                address = ?, 
                farm_size = ?, 
                products_grown = ?, 
                bio = ? 
            WHERE id = ?`,
            [firstName, lastName, email, phone, farmName, state, city, address, farmSize || null, products || null, bio || null, farmerId]
        );
        
        connection.release();
        
        console.log('✅ Profile updated for farmer ID:', farmerId);
        
        res.json({ success: true, message: 'Profile updated successfully' });
        
    } catch (error) {
        console.error('Error updating profile:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

// ============ API ROUTES - ORDERS ============

app.get('/api/orders/farmer/:farmerId', async (req, res) => {
    let connection;
    try {
        const farmerId = parseInt(req.params.farmerId);
        
        if (isNaN(farmerId)) {
            return res.status(400).json({ error: 'Invalid farmer ID' });
        }
        
        connection = await db.getConnection();
        
        const [orders] = await connection.execute(
            `SELECT o.*, 
                    b.first_name as buyer_first_name, 
                    b.last_name as buyer_last_name,
                    b.phone as buyer_phone,
                    b.address as buyer_address
             FROM orders o
             JOIN buyers b ON o.buyer_id = b.id
             WHERE o.farmer_id = ?
             ORDER BY o.created_at DESC`,
            [farmerId]
        );
        
        for (let order of orders) {
            const [items] = await connection.execute(
                `SELECT oi.*, p.name as product_name, p.unit 
                 FROM order_items oi
                 JOIN products p ON oi.product_id = p.id
                 WHERE oi.order_id = ?`,
                [order.id]
            );
            order.items = items;
            order.buyer_name = `${order.buyer_first_name || ''} ${order.buyer_last_name || ''}`.trim() || 'Customer';
        }
        
        connection.release();
        res.json({ success: true, orders: orders });
        
    } catch (error) {
        console.error('Error fetching orders:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

app.put('/api/orders/:orderId/status', async (req, res) => {
    let connection;
    console.log('✅ PUT /api/orders/:orderId/status');
    
    try {
        const orderId = parseInt(req.params.orderId);
        let { status } = req.body;
        
        if (isNaN(orderId)) {
            return res.status(400).json({ error: 'Invalid order ID' });
        }
        
        const validStatuses = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'];
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ error: 'Invalid status value' });
        }
        
        connection = await db.getConnection();
        
        const [result] = await connection.execute(
            'UPDATE orders SET status = ? WHERE id = ?',
            [status, orderId]
        );
        
        connection.release();
        
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Order not found' });
        }
        
        console.log('✅ Order status updated for order ID:', orderId);
        
        res.json({ success: true, message: 'Order status updated successfully' });
        
    } catch (error) {
        console.error('Error updating order status:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

app.post('/api/orders/create', async (req, res) => {
    let connection;
    console.log('✅ POST /api/orders/create');
    
    try {
        const { buyerId, deliveryAddress, notes, items } = req.body;
        
        if (!buyerId || !items || !Array.isArray(items) || items.length === 0) {
            return res.status(400).json({ error: 'Invalid order data' });
        }
        
        for (const item of items) {
            if (!item.product_id || !item.quantity || !item.price) {
                return res.status(400).json({ error: 'Invalid item data' });
            }
            if (item.quantity < 1 || item.quantity > 10000) {
                return res.status(400).json({ error: 'Invalid quantity' });
            }
        }
        
        connection = await db.getConnection();
        await connection.beginTransaction();
        
        const orderNumber = 'ORD' + Date.now();
        const farmerGroups = {};
        
        for (const item of items) {
            const [products] = await connection.execute(
                'SELECT farmer_id FROM products WHERE id = ?',
                [item.product_id]
            );
            
            if (products.length > 0) {
                const farmerId = products[0].farmer_id;
                if (!farmerGroups[farmerId]) {
                    farmerGroups[farmerId] = [];
                }
                farmerGroups[farmerId].push(item);
            }
        }
        
        for (const [farmerId, farmerItems] of Object.entries(farmerGroups)) {
            let orderTotal = 0;
            for (const item of farmerItems) {
                orderTotal += item.price * item.quantity;
            }
            
            const [orderResult] = await connection.execute(
                `INSERT INTO orders (order_number, buyer_id, farmer_id, total_amount, status, delivery_address, notes) 
                 VALUES (?, ?, ?, ?, 'pending', ?, ?)`,
                [orderNumber + '_' + farmerId, buyerId, farmerId, orderTotal, deliveryAddress || null, notes || null]
            );
            
            const orderId = orderResult.insertId;
            
            for (const item of farmerItems) {
                await connection.execute(
                    `INSERT INTO order_items (order_id, product_id, quantity, price) 
                     VALUES (?, ?, ?, ?)`,
                    [orderId, item.product_id, item.quantity, item.price]
                );
                
                await connection.execute(
                    'UPDATE products SET quantity = quantity - ? WHERE id = ?',
                    [item.quantity, item.product_id]
                );
            }
        }
        
        await connection.commit();
        connection.release();
        
        console.log('✅ Order created successfully');
        
        res.status(201).json({ success: true, message: 'Order placed successfully!' });
        
    } catch (error) {
        console.error('Error creating order:', error);
        if (connection) {
            await connection.rollback();
            connection.release();
        }
        res.status(500).json({ error: 'Server error: ' + error.message });
    }
});

app.get('/api/orders/buyer/:buyerId', async (req, res) => {
    let connection;
    try {
        const buyerId = parseInt(req.params.buyerId);
        
        if (isNaN(buyerId)) {
            return res.status(400).json({ error: 'Invalid buyer ID' });
        }
        
        connection = await db.getConnection();
        
        const [orders] = await connection.execute(
            `SELECT o.*, f.farm_name 
             FROM orders o
             JOIN farmers f ON o.farmer_id = f.id
             WHERE o.buyer_id = ?
             ORDER BY o.created_at DESC`,
            [buyerId]
        );
        
        for (let order of orders) {
            const [items] = await connection.execute(
                `SELECT oi.*, p.name as product_name, p.unit 
                 FROM order_items oi
                 JOIN products p ON oi.product_id = p.id
                 WHERE oi.order_id = ?`,
                [order.id]
            );
            order.items = items;
        }
        
        connection.release();
        res.json({ success: true, orders: orders });
        
    } catch (error) {
        console.error('Error fetching buyer orders:', error);
        if (connection) connection.release();
        res.status(500).json({ error: 'Server error' });
    }
});

// ============ TEST ROUTE ============

app.get('/api/test', (req, res) => {
    res.json({ message: 'API is working!', timestamp: new Date() });
});

// ============ 404 HANDLER ============

app.use((req, res) => {
    res.status(404).json({ error: 'Route not found' });
});

// ============ START SERVER ============

app.listen(PORT, () => {
    console.log(`\n🚀 Server running on http://localhost:${PORT}`);
    console.log(`📡 API Test: http://localhost:${PORT}/api/test`);
    console.log(`\n✅ Security features enabled:`);
    console.log(`   • Password hashing (bcrypt)`);
    console.log(`   • Input validation & sanitization`);
    console.log(`   • SQL Injection prevention (parameterized queries)`);
    console.log(`   • South African phone number validation`);
    console.log(`   • Strong password requirements`);
});